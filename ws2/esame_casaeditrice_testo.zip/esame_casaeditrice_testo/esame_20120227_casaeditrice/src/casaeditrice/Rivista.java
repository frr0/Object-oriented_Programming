package casaeditrice;

public class Rivista extends Pubblicazione{

	public void setIsbn(String isbn){
	}
	
}

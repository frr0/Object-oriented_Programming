package casaeditrice;

public class Conferenza extends Pubblicazione{

	public void setLuogo(String luogo) {
	}
	
}

package casaeditrice;

import java.util.Collection;

public class Autore {

	public String getNome(){
		return null;
	}

	public String getCognome(){
		return null;
	}

	public String getEmail(){
		return null;
	}
	
	public int getCodice(){
		return -1;
	}
	
	public Pubblicazione aggiungiPubblicazione(String titolo, char tipologia, String volume, int anno, int contributo) {
		return null;
	}
	
	public Collection<Pubblicazione> elencoPubblicazioni(){
		return null;
	}
	
}

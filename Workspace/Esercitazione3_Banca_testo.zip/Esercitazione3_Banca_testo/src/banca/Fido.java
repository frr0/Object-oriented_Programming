package banca;

public class Fido {

	public String descriviti() {
		return null;
	}

}

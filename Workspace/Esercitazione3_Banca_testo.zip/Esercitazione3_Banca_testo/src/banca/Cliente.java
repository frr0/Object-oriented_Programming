package banca;

public class Cliente {

	public String getCodiceFiscale() {
		return null;
	}

	public String getCognome() {
		return null;
	}

	public String getNome() {
		return null;
	}

	public String getProfessione() {
		return null;
	}

	public String descriviti() {
		return null;
	}
	
}

package banca;

public class Conto {
	
	public String getCodice() {
		return null;
	}

	public double getTassoInteresse() {
		return -1;
	}

	public double getCapitale() {
		return -1;
	}

	public String getDataApertura() {
		return null;
	}

	public String getNomeOperatore() {
		return null;
	}

	public String getNomeFiliale() {
		return null;
	}

	public String descriviti() {
		return null;
	}

}

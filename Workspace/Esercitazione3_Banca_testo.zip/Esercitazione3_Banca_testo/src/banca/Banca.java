package banca;

public class Banca {

	public Banca() {
	}
	
	public Conto nuovoConto(double tassoInteresse, double capitale, String dataApertura, String nomeOperatore, String nomeFiliale) {
		return null;
	}

	public Conto cercaConto(String codiceConto) {
		return null;
	}

	public Conto[] cercaConti(String daCercare) {
		return null;
	}
	
	public Cliente nuovoCliente(String codiceFiscale, String cognome, String nome, String professione) {
		return null;
	}
	
	public Cliente cercaCliente(String codiceFiscale) {
		return null;
	}
	
	public boolean[] associaClienteConto(String codiceFiscale, String[] codiciConto) {
		return null;
	}
	
	public Cliente intestatario(String codiceConto) {
		return null;
	}

	public String contiCliente(String codiceFiscale) {
		return null;
	}

	public String clientiConto(String codiceConto) {
		return null;
	}
	
	public Fido nuovoPrestito(String codiceConto, String codiceCliente, double importo, double rataMensile, double tassoRischio) {
		return null;
	}
	
	public Mutuo nuovoPrestito(String codiceConto, String codiceCliente, double importo, double rataMensile, int numeroMesi) {
		return null;
	}

	public Prestito[] prestiti() {
		return null;
		
	}
	
	public Prestito[] prestiti(String codiceFiscale) {
		return null;
	}
	
	public Prestito[] prestiti(String codiceFiscale, String tipo) {
		return null;
	}
}



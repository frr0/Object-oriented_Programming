package banca;

public class Mutuo {

	public String descriviti() {
		return null;
	}

}

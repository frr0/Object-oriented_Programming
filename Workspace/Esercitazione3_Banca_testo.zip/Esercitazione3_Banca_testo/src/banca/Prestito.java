package banca;

public class Prestito {

	public String descriviti() {
		return null;
	}
	
}

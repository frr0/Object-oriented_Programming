package palestra;

@SuppressWarnings("serial")
public class SchedaNonEsistenteException extends Exception {
	
}

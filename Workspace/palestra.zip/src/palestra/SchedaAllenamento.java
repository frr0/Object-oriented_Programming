package palestra;

public class SchedaAllenamento {
	
	public String getCodice() {
		return null;
	}
}

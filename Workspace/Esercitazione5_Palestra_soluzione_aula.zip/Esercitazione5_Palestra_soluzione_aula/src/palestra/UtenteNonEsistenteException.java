package palestra;

@SuppressWarnings("serial")
public class UtenteNonEsistenteException extends Exception {

}

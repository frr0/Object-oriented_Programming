package aeroporto;

public class Tratta {

    String nomeT;
    int capienza;
    int kmXTratta;
    int id;
    
    public Tratta(String nomeT, int capienza, int kmXTratta, int id) {
        this.nomeT = nomeT;
        this.capienza = capienza;
        this.kmXTratta = kmXTratta;
        this.id = id;
    }
}

package banca;

public class prova {
  int a;

  public void setA(int a) {
    this.a = a;
  }

  public int getA() {
    return a;
  }

  public prova(int a) {
    this.a = a;
  }

}


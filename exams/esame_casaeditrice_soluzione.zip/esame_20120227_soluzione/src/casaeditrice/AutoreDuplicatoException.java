package casaeditrice;

@SuppressWarnings("serial")
public class AutoreDuplicatoException extends Exception {

}

package casaeditrice;

@SuppressWarnings("serial")
public class AutoreInesistenteException extends Exception {

}

package piscine;

public class PostoBordo extends Posto {

	public boolean getOmbrellone() {
		return false;
	}
	
	public int getNumLettini() {
		return -1;
	}



}

package piscine;

@SuppressWarnings("serial")
public class EccezioneTipoPostoEsaurito extends Exception {

}

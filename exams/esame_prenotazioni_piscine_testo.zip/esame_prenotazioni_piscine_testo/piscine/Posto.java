package piscine;

public class Posto {

	public String getNumero() {
		return null;
	}
	
}

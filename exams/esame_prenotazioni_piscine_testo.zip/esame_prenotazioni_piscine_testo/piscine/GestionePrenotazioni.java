package piscine;

import java.util.*;

public class GestionePrenotazioni {

	public Piscina definisciPiscina(String indirizzoPiscina, int numPostiBordoPiscina, int numPostiPrato, int maxOccupantiPosto) {
		return null;
	}

	public Piscina cercaPiscina(String indirizzoPiscina) {
		return null;
	}
	
	public Collection<Piscina> elencoPiscine(){
		return null;
	}
	
	public Collection<Posto> elencoPostiBordoPiscina(String indirizzoPiscina){
		return null;
	}
	
	public Collection<Posto> elencoPostiPrato(String indirizzoPiscina){
		return null;
	}
	
	public Posto cercaPosto(String indirizzoPiscina, String numeroPosto) {
		return null;
	}
	
	public void configuraPosto(String indirizzoPiscina, String numeroPosto, boolean ombrellone, int numLettini) {
	}
	
	public String nuovaPrenotazione(String indirizzoPiscina, String data, char tipoPosto, String nome, String cognome, String cellulare) throws EccezioneTipoPostoEsaurito {
		return null;
	}
	
	public Piscina piscinaPrenotazione(String codicePrenotazione) {
		return null;
	}

	public String dataPrenotazione(String codicePrenotazione) {
		return null;
	}

	public Posto postoPrenotazione(String codicePrenotazione) {
		return null;
	}
	
	public String stampaPrenotazione(String codicePrenotazione) {
		return null;
	}

	public String stampaPrenotazioniPerCodice() {
		return null;
	}

	public String stampaPrenotazioniPerCognomeNome() {
		return null;
	}
	
	public String stampaDatePrenotatePosto(String indirizzoPiscina, String numeroPosto) {
		return null;
	}
	
	public String StampaNumeroPostiLiberiData(String indirizzoPiscina, String data) {
		return null;
	}
	
    public void leggi(String filename){
    }    	
	
}

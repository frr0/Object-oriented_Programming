package piscine;

public class Piscina {

	public String getCodice() {
		return null;
	}

	public String getIndirizzo() {
		return null;
	}

	public int getNumPostiBordoPiscina() {
		return -1;
	}

	public int getNumPostiPrato() {
		return -1;
	}

	public int getMaxOccupantiPosto() {
		return -1;
	}

}

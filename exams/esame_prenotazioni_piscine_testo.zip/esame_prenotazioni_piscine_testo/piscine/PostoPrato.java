package piscine;

public class PostoPrato extends Posto {

}
